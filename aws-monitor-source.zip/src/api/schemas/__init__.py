# API Pydantic Schemas
