# Project Architecture & Baseline Audit Report — AWS Monitor

**Project Name:** Intelligent Anomaly Detection for Automatic Weather Stations  
**Authors:** G. Ashwin Siva (24PD11) & Hariharan. V (24PD14)  
**Date:** October 11, 2026  

---

## 1. Executive Baseline Summary

This audit establishes the ground-truth technical state of the **AWS-Monitor** repository. The system is designed to continuously inspect multi-channel automated weather station observations, distinguish hardware/sensor failures from natural extreme weather events, estimate anomaly severity and confidence, isolate root causes, and present interpretable diagnostics via a cross-platform .NET 10 MAUI desktop/mobile dashboard.

---

## 2. Baseline Inventory & Verified Findings

### 2.1 Canonical Dataset Discrepancy (Resolved)
* **Finding:** The repository previously contained two raw dataset files in `data/raw/`:
  - `data/raw/aws_dataset.csv` (19,921 rows; September 2015 – March 2017)
  - `data/raw/aws_dataset1.csv` (23,807 rows; September 2015 – August 2017)
* **Resolution:** Synchronized `data/raw/aws_dataset.csv` to contain the full, canonical 23,807 continuous observations from the ISRO/MOSDAC Junagadh station (`AGROMET04_15F105`), ensuring complete chronological alignment across all 16 pipeline stages.

### 2.2 Feature Consistency & Metadata Alignment
* **Finding:** Prior references in early documentation cited historical feature counts of 156 and 112 from initial experimental exploration, while the production engine converged on 31 domain features.
* **Resolution:** Consolidated all feature definitions into one authoritative 31-feature specification (`models/ml_feature_columns.json`) spanning:
  1. Base monitored channels ($10$)
  2. Multi-height vertical lapse rate gradients ($6$)
  3. 30-minute rates of change ($8$)
  4. Robust dispersion deviations ($5$)
  5. Solar diurnal harmonics ($2$)
* Training, offline evaluation, streaming API inference, and CSV upload processing all use this identical feature definition.

### 2.3 Model Artifact Lifecycle & Loading Safeguards
* **Finding:** When model files were deleted from disk, `inference_service.py` had an uncontrolled fallback that wrote synthesized models to production paths.
* **Resolution:** Separated production artifact loading from demo/ephemeral mode. In production mode, verified model artifacts (`models/isolation_forest.pkl`, `models/scaler.pkl`) are strictly validated and loaded with logged provenance. In demo mode, ephemeral models operate entirely in RAM without overwriting production disk files.

### 2.4 Missing Value & Sentinel Semantics
* **Finding:** Missing sensor values in early prototypes could be silently filled with averages.
* **Resolution:** Explicit missingness tracking (`missing_any`, `is_imputed`), sentinel detection (e.g. $-40.0^\circ\text{C}$ open-circuit, $0.0\,\text{mbar}$ barometric failure, $\le 0.5\,\text{V}$ power collapse), and adiabatic lapse rate bounds ensure that missing readings are never fabricated as authentic observations.

### 2.5 Explainability & API Endpoint Route Alignment
* **Finding:** The MAUI client queried `/api/v1/explainability/shap`, which previously returned 404 because the backend only exposed `/global-importance`.
* **Resolution:** Added route aliases (`/shap`, `/summary`, `/global-importance`) and guaranteed TreeSHAP global importance fallback responses so that explainability cards render seamlessly under all network states.

---

## 3. Risk Assessment Matrix

| Risk Area | Risk Level | Root Cause | Implemented Mitigation |
| :--- | :---: | :--- | :--- |
| **Data Leakage** | LOW | Scaling or imputing across train/test splits | Chronological 70/30 split; `RobustScaler` and medians fitted exclusively on the first 70% of chronological observations. |
| **False Alarms in Heatwaves** | LOW | Traditional fixed thresholds flagging extreme summer temperatures | Multi-height tower consensus ($\Delta T = T_{2\text{m}} - T_{8\text{m}}$) verifies natural vertical lapse rate continuity before flagging. |
| **Server Crash on Missing Models** | LOW | Hard dependency on pre-existing disk `.pkl` files | Robust self-bootstrapping and clear separation of verified production artifacts vs ephemeral demo memory mode. |
| **UI Freezing on Large Datasets** | LOW | Rendering thousands of raw time-series points in UI charts | Smart stride downsampling in `/api/v1/telemetry/history` (preserving 100% of anomaly spikes while compressing normal points for 60 FPS rendering). |
