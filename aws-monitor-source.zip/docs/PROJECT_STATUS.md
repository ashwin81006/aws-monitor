# Project Status Matrix — AWS Monitor

**Project Name:** Intelligent Anomaly Detection for Automatic Weather Stations (AWS-Monitor)  
**Authors:** G. Ashwin Siva (24PD11) & Hariharan. V (24PD14)  
**Date:** October 11, 2026  

---

## 📊 Subsystem Status Overview

| Subsystem | Components | Status | Verification Evidence |
| :--- | :--- | :---: | :--- |
| **Canonical Data Pipeline** | `data/raw/aws_dataset.csv`, `src/preprocessing/clean_aws.py`, missingness flags | **COMPLETE & TESTED** | Verified 23,807 continuous records; `tests/test_dataset_schema.py` passed. |
| **Feature Engineering Engine** | `src/features/build_features.py` (31 Domain Features) | **COMPLETE & TESTED** | 10 base channels + 6 lapse gradients + 8 rates of change + 5 robust deviations + 2 solar diurnal cycles; `tests/test_features.py` passed. |
| **ML Training & Preparation** | `src/ml/prepare_ml_data.py`, `src/ml/isolation_forest.py` | **COMPLETE & TESTED** | Chronological 70/30 split, no data leakage, RobustScaler fitted on training split only; `tests/test_models.py` passed. |
| **Benchmark Models** | `src/ml/local_outlier_factor.py`, `src/ml/one_class_svm.py`, `src/ml/model_comparison.py` | **COMPLETE & TESTED** | Evaluated on identical test sets; Isolation Forest selected with 87,650 obs/sec throughput and 981 KB footprint. |
| **Rule QC & Physics Detection** | `src/detection/rule_qc.py`, `src/detection/cross_sensor_evidence.py`, `src/detection/temporal_evidence.py` | **COMPLETE & TESTED** | Sentinels, vertical lapse rates ($\Delta T$), 30-min rates of change, battery brownout, and heatwave consensus verified; `tests/test_detection_rules.py` passed. |
| **Bayesian Evidence Fusion** | `src/detection/build_evidence_matrix.py`, `src/detection/event_fusion.py` | **COMPLETE & TESTED** | Noisy-OR probabilistic multi-layer fusion matrix and temporal clustering; `tests/test_fusion.py` passed. |
| **Fault Injection Validation** | `src/validation/inject_faults.py`, `src/validation/evaluate_validation.py`, `src/validation/run_validation.py` | **COMPLETE & TESTED** | Injected SPIKE, DRIFT, FROZEN_SENSOR, COMMUNICATION_FAILURE scenarios with reproducible ground truth. |
| **Model Explainability (SHAP)** | `src/explainability/shap_explainer.py`, `src/api/routes/explainability.py` | **COMPLETE & TESTED** | TreeSHAP exact path decomposition, global importance rankings, and per-event waterfall attributions. |
| **FastAPI REST API** | `src/api/app.py`, `src/api/routes/`, `src/api/services/` | **COMPLETE & TESTED** | OpenAPI/Swagger docs at `/docs`, streaming inference, downsampled history, dynamic CSV upload; `tests/test_api_endpoints.py` passed (8/8). |
| **.NET 10 MAUI Desktop/Mobile UI** | `ui/AwsMonitor.UI/` (C# / XAML + LiveCharts2) | **COMPLETE & TESTED** | Compiled with 0 errors/0 warnings; 6 tabs (Overview, Telemetry, Test Faults, Incidents, Sensor Health, AI Models). |
| **Automated Test Suite** | `tests/run_tests.py` | **COMPLETE & TESTED** | 22/22 unit and integration tests passing. |
| **Postman API Collection** | `tests/postman/AWS_Monitor_API.postman_collection.json` | **COMPLETE & TESTED** | Validated against running API. |
