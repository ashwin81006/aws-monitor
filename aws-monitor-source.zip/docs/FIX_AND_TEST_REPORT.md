# Fix & Test Report — AWS Monitor

**Project Name:** Intelligent Anomaly Detection for Automatic Weather Stations  
**Authors:** G. Ashwin Siva (24PD11) & Hariharan. V (24PD14)  
**Date:** October 11, 2026  

---

## 1. Summary of Implemented Fixes

| Issue ID | Affected Subsystem | Files Modified | Description of Fix |
| :--- | :--- | :--- | :--- |
| **FIX-01** | Raw Dataset Synchronization | `data/raw/aws_dataset.csv` | Synchronized canonical dataset to the complete 23,807-row continuous record (September 2015 to August 2017). |
| **FIX-02** | Model Comparison & Benchmarks | `src/api/routes/models.py`, `ui/AwsMonitor.UI/MainPage.xaml`, `ui/AwsMonitor.UI/Models/DiagnosticModels.cs` | Populated full benchmark comparison table across Isolation Forest (87,650 obs/s), One-Class SVM (29,953 obs/s), and LOF (15,917 obs/s); added status badges and selection rationale. |
| **FIX-03** | Explainability Route Mapping | `src/api/routes/explainability.py`, `src/api/services/explainability_service.py` | Added `/shap` and `/summary` aliases for `/global-importance` to resolve 404 HTTP errors in client calls; provided TreeSHAP fallback importance distributions. |
| **FIX-04** | Dynamic CSV Activation | `src/api/services/dataset_processor.py`, `src/api/routes/telemetry.py`, `ui/AwsMonitor.UI/ViewModels/MainViewModel.cs` | Enabled on-the-fly CSV ingestion, multi-height domain feature extraction, real-time ML inference, and reactive MAUI dashboard reloading across all tabs. |
| **FIX-05** | Model Lifecycle & Demo Mode | `src/api/services/inference_service.py` | Enhanced model loading with logged production provenance (`1.0.0-PROD`), strict validation, and ephemeral in-memory fallback without overwriting production files. |
| **FIX-06** | App Server Startup from Any CWD | `src/api/app.py` | Passed FastAPI `app` object directly to `uvicorn.run()` so running `python app.py` works from any working directory. |
| **FIX-07** | Response Schema Harmonization | `src/api/schemas/telemetry.py`, `src/api/services/inference_service.py` | Added `fused_anomaly_score` and `root_cause` property aliases to `TelemetryInferenceResponse` for unified client and test consumption. |

---

## 2. Quantitative Model Evaluation & Benchmark Results

### 2.1 Multi-Model Performance Comparison (Evaluation on 7,143 Test Observations)

| Model | Production Role | Fit Time (s) | Inference Throughput (obs/sec) | Model Disk Size | TreeSHAP Supported | Production Verdict |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **Isolation Forest** | **Primary Detector** | **0.19s** | **87,650 obs/s** | **981 KB** | ✅ **Yes (Exact)** | **Selected for Production** |
| **One-Class SVM** | Baseline (Kernel Margin) | 4.21s | 29,953 obs/s | 46 KB | ⚠️ Approximation | Baseline (22x slower training) |
| **Local Outlier Factor (LOF)** | Baseline (Density) | 1.12s | 15,917 obs/s | 6,920 KB | ⚠️ Approximation | Baseline (Heavy 6.9MB RAM) |

---

## 3. Automated Test Execution Results

Executed automated test suite via `python tests/run_tests.py`:

```
======================================================================
             AWS MONITOR AUTOMATED TEST RUNNER
======================================================================

>> Running Suite: Dataset Schema Tests
  [PASS] test_canonical_raw_dataset_exists
  [PASS] test_processed_clean_dataset
  [PASS] test_required_columns_present

>> Running Suite: Feature Specification Tests
  [PASS] test_31_ml_feature_columns
  [PASS] test_processed_features_file

>> Running Suite: Model & ML Inference Tests
  [PASS] test_isolation_forest_inference
  [PASS] test_production_artifacts_exist
  [PASS] test_single_point_stream_inference

>> Running Suite: Physics & Bayesian Detection Rule Tests
  [PASS] test_battery_brownout_detection
  [PASS] test_heatwave_consensus_no_false_alarm
  [PASS] test_sentinel_hardware_fault
  [PASS] test_spike_divergence_detection

>> Running Suite: Evidence Matrix & Fusion Tests
  [PASS] test_event_fusion_clustering
  [PASS] test_evidence_matrix_structure

>> Running Suite: FastAPI REST Endpoint Tests
  [PASS] test_csv_upload
  [PASS] test_explainability_endpoints
  [PASS] test_health_check
  [PASS] test_model_benchmark
  [PASS] test_sensor_health
  [PASS] test_station_summary
  [PASS] test_streaming_point_inference
  [PASS] test_telemetry_history

======================================================================
TEST SUMMARY: 22 Passed | 0 Failed | Total: 22
======================================================================
```

---

## 4. .NET MAUI Client Build Verification

Executed build via `dotnet build ui/AwsMonitor.UI/AwsMonitor.UI.csproj -f net10.0-windows10.0.19041.0`:
* **Status:** Build Succeeded
* **Errors:** 0
* **Warnings:** 0
* **Compilation Time:** 4.10 seconds
