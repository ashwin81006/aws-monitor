import os
import zipfile
from pathlib import Path

root = Path.cwd()
output = root.parent / "aws-monitor-source.zip"

skip_dirs = {
    ".git", ".venv", "venv", "__pycache__",
    ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "node_modules", "bin", "obj", ".vs"
}

with zipfile.ZipFile(
    output, "w", compression=zipfile.ZIP_DEFLATED
) as z:
    for current, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in skip_dirs)

        for name in files:
            path = Path(current) / name
            rel = path.relative_to(root)

            if path == output or path.suffix.lower() == ".zip":
                continue

            parts = rel.parts

            # Exclude bulky generated datasets, not source code.
            if parts[0] == "data" and len(parts) > 1:
                if parts[1] in {"raw", "processed"}:
                    if path.suffix.lower() == ".csv":
                        continue

            if "reports" in parts and "figures" in parts:
                continue

            z.write(path, rel.as_posix())

print("Created:", output)
print("Size (MB):", round(output.stat().st_size / 1048576, 2))